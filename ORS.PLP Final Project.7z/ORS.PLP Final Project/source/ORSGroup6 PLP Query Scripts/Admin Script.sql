--Admin Login Table

CREATE TABLE ORSGroup6.AdminLogin
(
	UserName	VARCHAR(10),
	Password	VARCHAR(10)
)

INSERT INTO ORSGroup6.AdminLogin (UserName, Password)
VALUES ('admin', 'admin')

--Procedure To Validate Admin

CREATE PROC ORSGroup6.ValidateAdmin
(
	@User	VARCHAR(10),
	@Password VARCHAR(10)
)
AS
BEGIN
	SELECT UserName FROM ORSGroup6.AdminLogin
	WHERE UserName = @User AND Password = @Password
END

select * from ORSGroup6.JobDetails

--Procedure To Get Job Details

Create Procedure ORSGroup6.GetJobDetails
AS
BEGIN
select * from ORSGroup6.JobDetails;
END

exec  ORSGroup6.GetJobDetails;

--Procedure to Delete Expired Jobs

ALTER PROC ORSGroup6.deleteexpjobs
(
@jobid int
)
AS
BEGIN
Delete from ORSGroup6.AppliedJobs where JobId=@jobid
Delete from ORSGroup6.JobDetails where JobId=@jobid
END

Exec ORSGroup6.deleteexpjobs 3


