﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;

namespace WebApplication2
{
    /// <summary>
    /// Class to view JobApplications
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It consists of view JobApplications Page
    /// </summary>
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser.Text = "Welcome " + Session["user"];
            lblempid.Text = "Your ID " + Session["empid"];
            Master.LogoutVisible = true;
        }

        EmployersValidation validationObj = new EmployersValidation();

        protected void btnjobapp_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable jobappTable = new DataTable();
                int empid = Convert.ToInt32(Session["empid"]);
                int jobid = Convert.ToInt32(txtjobid.Text);

                jobappTable = validationObj.GetJobApplications(empid, jobid);
                if(jobappTable.Rows.Count>0)
                {
                gvjobapp.DataSource = jobappTable;
                gvjobapp.DataBind();
                }
                else
                    Response.Write("<script>alert('Data is not available');</script>");
            }
            catch (EmployersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}