﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;


namespace ORS.BL
{
    /// <summary>
    /// Class Contains Admin Validations
    /// Author: ORSGroup6
    /// Date Modified: 04/08/2017
    /// Description: It contains method for different Admin's Details Validation 
    /// </summary>
    public class AdminValidations
    {
        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Validation of Admin Credentials 
        /// </summary>
        public static string ValidateAdmin(AdminEntity user)
        {
            string userName = null;

            try
            {
                userName = AdminOperations.ValidateAdmin(user);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return userName;
        }

        AdminOperations adminObj = new AdminOperations();

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate retrieval of Job Details 
        /// </summary>
        public DataTable GetJobDetails()
        {
            DataTable jobTable = new DataTable();
            try
            {
                jobTable = adminObj.GetJobDetails();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobTable;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Deletion of Expired Jobs 
        /// </summary>
        public static int DeleteExpJobs(int jobID)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = AdminOperations.DeleteExpJobs(jobID);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
