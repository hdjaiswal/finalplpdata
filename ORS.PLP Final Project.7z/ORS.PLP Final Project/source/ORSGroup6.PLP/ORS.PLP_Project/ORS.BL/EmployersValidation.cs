﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;

namespace ORS.BL
{
    /// <summary>
    /// Class Contains Employer Validations
    /// Author: ORSGroup6
    /// Date Modified: 04/08/2017
    /// Description: It contains method for different Employer's Details Validation 
    /// </summary>
    public class EmployersValidation
    {
        EmployerOperations empOp = new EmployerOperations();

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Employer's personal details 
        /// </summary>
       
        public bool AddEmployeeDetails(Employer jobj)
        {
            bool jsAdded = false;
            try
            {
                jsAdded = empOp.AddEmployeeDetails(jobj);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsAdded;
        }


        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Job's details Posted by Employee 
        /// </summary>
        public bool AddJobs(Employer jobj)
        {
            bool jobsAdded = false;
            try
            {
                jobsAdded = empOp.AddJobs(jobj);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobsAdded;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate retrieval Posted Job's details 
        /// </summary>
        public DataTable GetPostedJobs(int empid)
        {

            DataTable jobTable = new DataTable();
            try
            {
                jobTable = empOp.GetPostedJobs(empid);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobTable;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Job Applications 
        /// </summary>
        public DataTable GetJobApplications(int empid, int jobid)
        {
            DataTable jobTable = new DataTable();
            try
            {
                jobTable = empOp.GetJobApplications(empid, jobid);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobTable;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Validation of Employer Login credentials
        /// </summary>
        public static string ValidateUser(Employer user)
        {
            string empemail = null;
            
            try
            {
                empemail = EmployerOperations.ValidateLogin(user);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empemail;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate retrieval of Employee ID
        /// </summary>
        public static int GetEmployeeID(Employer user)
        {
            int empid=0;

            try
            {
                empid = EmployerOperations.GetEmployeeID(user);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empid;
        }
    }
}
