﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.Entity
{
    /// <summary>
    /// Entity to store Employer's Information
    /// Author: ORSGroup6
    /// Date Modified: 04/06/2017
    /// Description: Entity to store Employer's Information
    /// </summary>
    public  class Employer
    {
        /// <summary>
        /// Property to store and retrieve Employer's ID
        /// </summary>
        public int EmployeeID { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's First name
        /// </summary>
        public string EFirstName { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's LastName
        /// </summary>
        public string ELastName { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Company name
        /// </summary>
        public string ECompanyName { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Email-address
        /// </summary>
        public string EEmailAddress { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Designation
        /// </summary>
        public string EDesignation { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Location
        /// </summary>
        public string ELocation { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Phone no
        /// </summary>
        public Int64 EPhoneNo { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's  Password
        /// </summary>
        public string EPassword { get; set; }

        /// Property to store and retrieve Post 
        /// </summary>
        public string DPost { get; set; }
        /// <summary>
        /// Property to store and retrieve Job's Vacancies
        /// </summary>
        public int DVacancies { get; set; }
        /// <summary>
        /// Property to store and retrieve Job's Posted Date
        /// </summary>
        public DateTime DPostedDate { get; set; }
        /// <summary>
        /// Property to store and retrieve Job's Last Date to Apply
        /// </summary>
        public DateTime DLastDate { get; set; }
        /// <summary>
        /// Property to store and retrieve Company Description
        /// </summary>
        public string DDescription { get; set; }
        /// <summary>
        /// Property to store and retrieve Company Name
        /// </summary>
        public string DCompanyName { get; set; }
        /// <summary>
        /// Property to store and retrieve Package
        /// </summary>
        public Double DPackage { get; set; }
        /// <summary>
        /// Property to store and retrieve Job Location
        /// </summary>
        public string DJobLocation { get; set; }
        /// <summary>
        /// Property to store and retrieve Required Experience
        /// </summary>
        public string DExperience { get; set; }
    }
}
 