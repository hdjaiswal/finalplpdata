﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLibrary;

namespace ORS.DAL
{
    /// <summary>
    /// Class Contains EmployeeOperations
    /// Author: ORSGroup6
    /// Date Modified: 04/08/2017
    /// Description: It contains method for different Employee Operations 
    /// </summary>
    public class EmployerOperations
    {
        SqlDataReader reader;
        int result;

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to insert Employee details 
        /// </summary>
        public bool AddEmployeeDetails(Employer emp)
        {
            bool jsAdded = false;
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ORSGroup6.AddEmployee";
          
                cmd.Parameters.AddWithValue("@FirstName ", emp.EFirstName);
                cmd.Parameters.AddWithValue("@LastName", emp.ELastName);
                cmd.Parameters.AddWithValue("@EmailAddress", emp.EEmailAddress);
                cmd.Parameters.AddWithValue("@Companyname", emp.ECompanyName);
                cmd.Parameters.AddWithValue("@Password", emp.EPassword);
                cmd.Parameters.AddWithValue("@Designation", emp.EDesignation);
                cmd.Parameters.AddWithValue("@ContactNo", emp.EPhoneNo);
                cmd.Parameters.AddWithValue("@Location", emp.ELocation);

                cmd.Connection.Open();
                result = cmd.ExecuteNonQuery();
                cmd.Connection.Close();


                if (result > 0)
                    jsAdded = true;
               
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jsAdded;
            
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to insert Job details 
        /// </summary>
        public bool AddJobs(Employer emp)
        {
            bool jobsAdded = false;
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ORSGroup6.AddJobs";
               
                cmd.Parameters.AddWithValue("@CompanyName", emp.DCompanyName);
                cmd.Parameters.AddWithValue("@Post", emp.DPost);
                cmd.Parameters.AddWithValue("@Vacancies", emp.DVacancies);
                cmd.Parameters.AddWithValue("@PostedDate", emp.DPostedDate);
                cmd.Parameters.AddWithValue("@LastDate", emp.DLastDate);
                cmd.Parameters.AddWithValue("@CompanyDescription", emp.DDescription);
                cmd.Parameters.AddWithValue("@JobLocation", emp.DJobLocation);
                cmd.Parameters.AddWithValue("@Package", emp.DPackage);
                cmd.Parameters.AddWithValue("@Experience", emp.DExperience);
                cmd.Parameters.AddWithValue("@EmployeeID", emp.EmployeeID);

                cmd.Connection.Open();
                result = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

                if (result > 0)
                    jobsAdded = true;
               
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobsAdded;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to retrieve Posted Job details 
        /// </summary>
        public DataTable GetPostedJobs(int empid)
        {
            DataTable jobTable = new DataTable();
            try
            {
                SqlCommand cmdPJobs = DataConfiguration.CreateCommand();

                cmdPJobs.CommandText = "ORSGroup6.ViewjobsByEmployee";
                cmdPJobs.Parameters.AddWithValue("@EmployeeID", empid);
                cmdPJobs.Connection.Open();
                reader = cmdPJobs.ExecuteReader();

                jobTable.Load(reader);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobTable;

        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to retrieve Job Applications details 
        /// </summary>
        public DataTable GetJobApplications(int empid,int jobid)
        {
            DataTable jobTable = new DataTable();
            try
            {
                SqlCommand cmdjobapp = DataConfiguration.CreateCommand();

                cmdjobapp.CommandText = "ORSGroup6.viewsJobseekersDetailsTOEmployees";

                cmdjobapp.Parameters.AddWithValue("@EmployeeId", empid);
                cmdjobapp.Parameters.AddWithValue("@JobId", jobid);
                cmdjobapp.Connection.Open();
                reader = cmdjobapp.ExecuteReader();

                jobTable.Load(reader);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobTable;

        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Employee login credentials 
        /// </summary>
        public static string ValidateLogin(Employer user)
        {
            string empemail = null;
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "ORSGroup6.EmployeeVerification";

                cmd.Parameters.AddWithValue("@EmailAddress",user.EEmailAddress );
                cmd.Parameters.AddWithValue("@Password", user.EPassword);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
            
                if (dr.HasRows)
                {
                    dr.Read();
                    empemail = dr[0].ToString();
                  
                }
              
                cmd.Connection.Close();
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empemail;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to retrieve Employee ID 
        /// </summary>
        public static int GetEmployeeID(Employer user)
        {
            int empid = 0;
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "ORSGroup6.GetEmployeeID";

                cmd.Parameters.AddWithValue("@EmailAddress", user.EEmailAddress);
                cmd.Parameters.AddWithValue("@Password", user.EPassword);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    empid = Convert.ToInt32(dr[0]);
                }
               
                cmd.Connection.Close();
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empid;
        }

    }
}
