﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLibrary;

namespace ORS.DAL
{

    /// <summary>
    /// Class Contains Admin Operations
    /// Author: ORSGroup6
    /// Date Modified: 04/08/2017
    /// Description: It contains method for Admin Operations 
    /// </summary>
    public class AdminOperations
    {
        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Admin login credentials 
        /// </summary>
        public static string ValidateAdmin(AdminEntity user)
        {
            string userName = null;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "ORSGroup6.ValidateAdmin";

                cmd.Parameters.AddWithValue("@User", user.Username);
                cmd.Parameters.AddWithValue("@Password", user.Password);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    userName = dr[0].ToString();
                }
                
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return userName;
            
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to retrieve Job Details 
        /// </summary>
        public DataTable GetJobDetails()
        {
            DataTable jobTable = new DataTable();
            try
            {
                SqlCommand cmdgetjobdetails = DataConfiguration.CreateCommand();

                cmdgetjobdetails.CommandText = "ORSGroup6.GetJobDetails";


                cmdgetjobdetails.Connection.Open();
                SqlDataReader reader = cmdgetjobdetails.ExecuteReader();

                reader.Read();

                jobTable.Load(reader);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobTable;

        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to Delete Expired Job Details 
        /// </summary>
        public static int DeleteExpJobs(int jobID)
        {
            int recordAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "ORSGroup6.deleteexpjobs";
                cmd.Parameters.AddWithValue("@jobid", jobID);

                cmd.Connection.Open();
                recordAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordAffected;
        }
    }
}
